# PSW - Assessment de Perfis Comportamentais

Projeto estático (HTML único). Duas variantes:
- `index_publicacao_v5.html`: **produção** (sem ferramentas de teste)
- `index_publicacao_v5_dev.html`: **DEV** (com painel de preenchimento automático para testes)

## Como usar localmente
Basta abrir o arquivo `.html` no navegador.

## Publicar no GitHub
1. Crie um repositório **novo** no GitHub (público ou privado), ex.: `psw-assessment`.
2. Faça upload destes arquivos:
   - `index_publicacao_v5.html` (renomeie para `index.html` se quiser que seja a página padrão)
   - `index_publicacao_v5_dev.html` (opcional)
   - `README.md` (este arquivo)
3. Commit.

### Via Git (opcional)
```bash
mkdir psw-assessment && cd psw-assessment
cp /caminho/para/index_publicacao_v5.html index.html
git init
git add .
git commit -m "PSW assessment - publicação inicial"
git branch -M main
git remote add origin git@github.com:SEU_USUARIO/psw-assessment.git
git push -u origin main
```

## Deploy no Netlify
### Opção A — Conectar ao GitHub (recomendada)
1. Acesse https://app.netlify.com/ → **Add new site** → **Import an existing project**.
2. Autorize o GitHub e selecione o repositório.
3. Como é site **estático**, deixe **Build command** em branco (ou `npm run build` *vazio*) e **Publish directory** como `.` (raiz).
4. Clique **Deploy**. O Netlify fará o deploy automático a cada commit no GitHub.

### Opção B — Arrastar e soltar (manual)
1. Em https://app.netlify.com/ → **Add new site** → **Deploy manually**.
2. Arraste a pasta contendo o `index.html` (e demais arquivos) para a área de upload.
3. Feito!

## Dicas
- Para produção, renomeie `index_publicacao_v5.html` para **`index.html`**.
- Mantenha a **CSP** do arquivo. Se futuramente extrair o JS/CSS para arquivos externos, ajuste a CSP para remover `'unsafe-inline'`.
- Domínio: em **Site settings → Domain management**, adicione um domínio customizado se desejar.
- QR Code: depois de publicado, gere um QR a partir da **URL do site** (qualquer gerador de QR serve).

Boa publicação!
